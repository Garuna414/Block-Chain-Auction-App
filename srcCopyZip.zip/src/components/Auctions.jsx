import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../styles/auctions.css";
import img from "../assets/user.png";

function Auctions() {
  const [isFormOpen, setIsFormOpen] = useState(false);

  const formRef = React.createRef();

  function openForm() {
    setIsFormOpen(true);
  }

  function closeForm() {
    setIsFormOpen(false);
  }

  return (
    <>
      <div className="mainData">
        <p className="sub-heading">Auctions</p>
        <div className="itemContainer">
          <Link to="/bidding" className="bidLink">
            <div className="item1">
              <div className="img">
                <img src={img} className="itemImg" />
              </div>

              <div className="itemInfo">
                <p className="data">Item name</p>
                <p className="data">Category</p>
                <p className="data">Auction type</p>
                <p className="data">Starting bid</p>
              </div>
            </div>
          </Link>
          <Link to="/bidding" className="bidLink">
            <div className="item1">
              <div className="img">
                <img src={img} className="itemImg" />
              </div>

              <div className="itemInfo">
                <p className="data">Item name</p>
                <p className="data">Category</p>
                <p className="data">Auction type</p>
                <p className="data">Starting bid</p>
              </div>
            </div>
          </Link>
          <Link to="/bidding" className="bidLink">
            <div className="item1">
              <div className="img">
                <img src={img} className="itemImg" />
              </div>

              <div className="itemInfo">
                <p className="data">Item name</p>
                <p className="data">Category</p>
                <p className="data">Auction type</p>
                <p className="data">Starting bid</p>
              </div>
            </div>
          </Link>
          <Link to="/bidding" className="bidLink">
            <div className="item1">
              <div className="img">
                <img src={img} className="itemImg" />
              </div>

              <div className="itemInfo">
                <p className="data">Item name</p>
                <p className="data">Category</p>
                <p className="data">Auction type</p>
                <p className="data">Starting bid</p>
              </div>
            </div>
          </Link>
          <Link to="/bidding" className="bidLink">
            <div className="item1">
              <div className="img">
                <img src={img} className="itemImg" />
              </div>

              <div className="itemInfo">
                <p className="data">Item name</p>
                <p className="data">Category</p>
                <p className="data">Auction type</p>
                <p className="data">Starting bid</p>
              </div>
            </div>
          </Link>
          <Link to="/bidding" className="bidLink">
            <div className="item1">
              <div className="img">
                <img src={img} className="itemImg" />
              </div>

              <div className="itemInfo">
                <p className="data">Item name</p>
                <p className="data">Category</p>
                <p className="data">Auction type</p>
                <p className="data">Starting bid</p>
              </div>
            </div>
          </Link>
          
        </div>
      </div>
      <div className="statsData">
        <p className="sub-heading">Statistics</p>
        <button className="btn btn-success" onClick={() => openForm()}>
          Add Auction
        </button>
      </div>
      {isFormOpen && (
        <div className="itemForm" ref={formRef}>
          <button className="closeBtn" onClick={() => closeForm()}>
            X
          </button>
          <form className="form">
            Upload Image: <input type="file" />
            Item name: <input type="text" placeholder="Ex: Wooden Chair" />
            Item category:
            <select>
              <option selected>Select</option>
              <option>Furniture</option>
              <option>Jewelry</option>
              <option>Automobiles</option>
              <option>Electronics</option>
              <option>Real Estate</option>
              <option>NFT</option>
            </select>
            Auction type:
            <select>
              <option selected>Select</option>
              <option>English</option>
              <option>Dutch</option>
              <option>Reverse</option>
            </select>
            Starting bid (ETH):
            <input type="number" placeholder="Ex: 5.9" />
            <input type="submit" className="submit" />
          </form>
        </div>
      )}
    </>
  );
}

export default Auctions;
