import React from "react";

function wallet() {
  return (
    <>
      <div className="mainData">
        <p className="sub-heading">Wallet</p>
      </div>
      <div className="statsData">
        <p className="sub-heading">Statistics</p>
      </div>
    </>
  );
}

export default wallet;
