import React from "react";
import "../styles/expenses.css";
import img from "../assets/user.png";

function expenses() {
  return (
    <>
      <div className="mainData">
        <p className="sub-heading">Expenses</p>
        <div className="tncns">
          <p className="timeFrame">Today</p>
          <hr className="divider" />
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Wooden Chair</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">15.000</p>
            </div>
          </div>
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Monke NFT</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">99.99</p>
            </div>
          </div>
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Apple AirTag</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">35.750</p>
            </div>
          </div>
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Honda City</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">1099.000</p>
            </div>
          </div>
          <p className="timeFrame">10 January 2024</p>
          <hr className="divider" />
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Charizard Full Art</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">99.99</p>
            </div>
          </div>
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Parker Pen</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">29.99</p>
            </div>
          </div>
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Clash Royale Account</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">39.99</p>
            </div>
          </div>
          <div className="tncnInfo">
            <div className="iconDiv">
              <img src={img} alt="" className="tncnIcon" />
            </div>
            <div className="nameDiv">
              <p className="tncnName">Apple Gift Card</p>
            </div>
            <div className="costDiv">
              <p className="tncnCost">50.00</p>
            </div>
          </div>
        </div>
      </div>
      <div className="statsData">
        <p className="sub-heading">Statistics</p>
        <div className="categories">
          <div className="category">
            <div className="catNameBox">
              <p className="catName">Furniture</p>
            </div>
            <div className="catCostBox">
              <p className="catCost">15.000</p>
            </div>
          </div>
          <div className="category">
            <div className="catNameBox">
              <p className="catName">NFTs</p>
            </div>
            <div className="catCostBox">
              <p className="catCost">99.99</p>
            </div>
          </div>
          <div className="category">
            <div className="catNameBox">
              <p className="catName">Automobiles</p>
            </div>
            <div className="catCostBox">
              <p className="catCost">1099.000</p>
            </div>
          </div>
          <div className="category">
            <div className="catNameBox">
              <p className="catName">Electronics</p>
            </div>
            <div className="catCostBox">
              <p className="catCost">35.750</p>
            </div>
          </div>
          
        </div>
      </div>
    </>
  );
}

export default expenses;
