import React from "react";
import "../styles/bidding.css";
import img from "../assets/user.png";

function bidding() {
  return (
    <>
      <div className="mainData">
        <p className="sub-heading">Bidding</p>
        <div className="bidBox">
            <div className="bidImgBox">
                <img src={img} alt="" className="bidImg" />
            </div>
            <div className="bidInfoBox">
                <p className="bidData">Item Name</p>
                <p className="bidData">Item Catagory</p>
                <p className="bidData">Auction Type</p>
                <p className="bidData">Seller Rating</p>
                <p className="bidData">Starting Bid</p>
                <p className="bidData">Current Bid</p>
            </div>
        </div>
      </div>
      <div className="statsData">
        <p className="sub-heading">Bidders</p>
        <div className="bidderList">
            <div className="bidder">
                <div className="bidderNameBox">
                    <p className="bidderName">Bidr 3</p>
                </div>
                <div className="bidValueBox">
                    <p className="bidValue">30.00</p>
                </div>
            </div>
            <div className="bidder">
                <div className="bidderNameBox">
                    <p className="bidderName">Bidr 2</p>
                </div>
                <div className="bidValueBox">
                    <p className="bidValue">25.00</p>
                </div>
            </div>
            <div className="bidder">
                <div className="bidderNameBox">
                    <p className="bidderName">Bidr 1</p>
                </div>
                <div className="bidValueBox">
                    <p className="bidValue">20.00</p>
                </div>
            </div>
        </div>
      </div>
    </>
  );
}

export default bidding;





// import React from "react";
// import "../styles/bidding.css";

// function bidding() {
//   return (
//     <>
//       <div className="mainData">
//         <p className="sub-heading">Bidding</p>
//       </div>
//       <div className="statsData">
//         <p className="sub-heading">Bidders</p>
//       </div>
//     </>
//   );
// }

// export default bidding;
