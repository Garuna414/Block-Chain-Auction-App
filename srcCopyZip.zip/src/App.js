import logo from "./logo.svg";
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Navigation from "./components/navigation";
import Expenses from "./components/expenses";
import Earnings from "./components/earnings";
import Wallet from "./components/wallet";
import Auctions from "./components/Auctions";
import Bidding from "./components/bidding";

function App() {
  return (
    <BrowserRouter>
      <div className="mainContainer">
        <div className="leftContainer">
          <Navigation />
        </div>
        <div className="rightContainer">
          <Routes>
            <Route exact path="/expenses" element={<Expenses />}></Route>
            <Route exact path="/earnings" element={<Earnings />}></Route>
            <Route exact path="/wallet" element={<Wallet />}></Route>
            <Route exact path="/auctions" element={<Auctions />}></Route>
            <Route exact path="/bidding" element={<Bidding />}></Route>
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
