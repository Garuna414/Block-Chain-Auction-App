import React, { useState, useEffect } from "react";
import {ethers} from 'ethers'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Navigation from "./components/navigation";
import Expenses from "./components/Expenses";
import Earnings from "./components/earnings";
import Wallet from "./components/wallet";
import Auctions from "./components/Auctions";
import Bidding from "./components/bidding";
import Navbar from "./components/Navbar";
import Web3 from "web3";

function App() {
  const [account, setAccount] = useState("");
  const [balance, setBalance] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadWeb3AndData = async () => {
      const connected = await loadWeb3();

      if (connected) {
        await loadBlockchainData();
      }
    };

    loadWeb3AndData();
  }, []);

  async function loadWeb3() {
    if (window.ethereum) {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      window.web3 = new Web3(window.ethereum);
      return true;
    } else {
      window.alert("No metamask detected!!");
      return false;
    }
  }

  async function loadBlockchainData() {
    const web3 = window.web3;
    const accounts = await web3.eth.getAccounts();
    console.log(accounts);
    setAccount(accounts[0]);
    setBalance(await getBalance(accounts[0]));
    setLoading(false); // Indicate loading is complete
  }

  async function getBalance(account) {
    const web3 = window.web3;
    const balanceInWei = await web3.eth.getBalance(account);
    const balanceInEth = web3.utils.fromWei(balanceInWei, "ether");
    return balanceInEth;
  }

  const [display, setDisplay] = useState("block");
  const [marginLeft, setMarginLeft] = useState("0");
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleWidth = () => {
    setIsExpanded(!isExpanded);
    setDisplay(isExpanded ? "block" : "none");
    setMarginLeft(isExpanded ? "0" : "150px");
  };

  return (
    <BrowserRouter>
      <div className="topContainer">
        <Navbar onButtonClick={toggleWidth} />
      </div>
      <div className="mainContainer">
        <div className="leftContainer" style={{ display: display }}>
          <Navigation account={account} balance={balance} />
        </div>
        <div className="rightContainer" style={{ marginLeft: marginLeft }}>
          <Routes>
            <Route exact path="/" element={<Expenses />}></Route>
            <Route exact path="/earnings" element={<Earnings />}></Route>
            <Route exact path="/wallet" element={<Wallet />}></Route>
            <Route exact path="/auctions" element={<Auctions />}></Route>
            <Route exact path="/bidding" element={<Bidding />}></Route>
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
