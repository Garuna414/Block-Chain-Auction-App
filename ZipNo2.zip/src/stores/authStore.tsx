import axios from 'axios';
import create from 'zustand';
import { provider } from '../initialisers/ethers.tsx'; // Assuming `signer` is exported from there
import { SiweMessage } from 'siwe';

type TAuthStore = {
  address: string;
  ready: boolean;
  loggedIn: boolean;
  connectWallet: () => void;
  signin: () => void;
  init: () => void;
};

export const authStore = create<TAuthStore>((set) => ({
  address: '',
  loggedIn: false,
  ready: false,

  init: async () => {
    try {
      const res = await axios.get('/api/validate');
      set({ address: res.data.address, loggedIn: true, ready: true });
    } catch (err) {
      const accounts = await provider.listAccounts();
      if (accounts[0]) {
        const address = await getAddress(); // Helper function to fetch address
        set({ ready: true, address });
      } else {
        set({ ready: true });
      }
    }
  },

  connectWallet: async () => {
    try {
      const accounts = await provider.send('eth_requestAccounts', []);
      if (accounts[0]) {
        const address = await getAddress();
        set({ address });
      }
    } catch (err) {
      console.log('user rejected request');
    }
  },

  signin: async () => {
    try {
      const signer = await getSigner(); // Helper function to fetch signer

      // Get nonce
      const res = await axios.get('/api/nonce');
      console.log(res.data);

      // Create message
      const messageRaw = new SiweMessage({
        domain: window.location.host,
        address: await signer.getAddress(),
        statement: 'Sign in with Ethereum to the app.',
        uri: window.location.origin,
        version: '1',
        chainId: 1,
        nonce: res.data,
      });

      const message = messageRaw.prepareMessage();

      // Get signature
      const signature = await signer.signMessage(message);

      // Send to server
      const res2 = await axios.post('/api/verify', { message, signature });

      set({ loggedIn: true });
    } catch (err) {}
  },
}));

export default authStore;

// Helper function to fetch signer
async function getSigner() {
  return await provider.getSigner();
}

// Helper function to fetch address (assuming it's needed elsewhere)
async function getAddress() {
  const signer = await getSigner();
  return await signer.getAddress();
}
