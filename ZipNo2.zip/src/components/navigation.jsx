import React from "react";
import "../styles/navigation.css";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";
import img from "../assets/user.png";

function navigation({account, balance}) {
  return (
    <div className="dashContainer">
      <p className="heading">Dashboard</p>
      <div className="self-info">
        <img src={img} alt="" className="userImg" />
        <p className="data-1">{account.slice(0,6)}.....{account.slice(-6)}</p>
        <p className="data-2">{balance} ETH</p>
        <p className="data-2">Rating: 4.3</p>
      </div>
      <div className="dash-nav">
        <Link to="/">
          <button type="button" className="btn btn-primary">
            Expenses
          </button>
        </Link>
        <Link to="/wallet">
          <button type="button" className="btn btn-primary">
            Wallet
          </button>
        </Link>
        <Link to="/earnings">
          <button type="button" className="btn btn-primary">
            Earnings
          </button>
        </Link>
        <Link to="/auctions">
          <button type="button" className="btn btn-primary">
            Auctions
          </button>
        </Link>
      </div>
    </div>
  );
}

export default navigation;
