import React from 'react'
import { Navigate } from 'react-router-dom'
import authStore from '../stores/authStore.tsx'

export default function wallet() {
  const s = authStore()

  if (s.loggedIn) return <Navigate to="/" />

  return (
    <div>
      {s.address === '' ? (
        <>
          <button onClick={s.connectWallet}>Connect wallet</button>
        </>
      ) : (
        <>
          <button onClick={s.signin}>Sign in</button>
        </>
      )}
    </div>
  )
}