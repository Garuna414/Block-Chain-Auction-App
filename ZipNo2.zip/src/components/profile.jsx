import React from "react";
import "../styles/profile.css";

function profile() {
  return (
    <div className="mainContainer">
      <div className="leftContainer">
        <p className="heading">Dashboard</p>
        <div className="self-info">
            
        </div>
        <div className="dash-nav">

        </div>
      </div>
      <div className="rightContainer">
        <p className="sub-heading">Expenses</p>
      </div>
    </div>
  );
}

export default profile;
