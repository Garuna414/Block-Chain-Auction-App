import { BrowserProvider } from "ethers";

// @ts-ignore
export const provider = new BrowserProvider(window.ethereum);
export const signer = provider.getSigner()